package Test_Cases;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.IOException;

public class Fill_out_form {


    public Fill_out_form() throws IOException {
    }

    @Test
    public void Fill_out_form() throws InterruptedException, IOException {
        // WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Voss-Assessment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        ChromeDriver driver = new ChromeDriver(op);
        driver.get("https://www.ultimateqa.com/automation/");
        Thread.sleep(5500);

        //Fill the form
        driver.findElement(By.xpath("//*[@id=\"post-507\"]/div/div[1]/div/div[2]/div/div[1]/div/div/div/div/ul/li[4]/a")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//*[@id=\"et_pb_contact_form_0\"]/div[2]/form/div/button")).click();
        Thread.sleep(5500);
        CharSequence Xolisa = "xolisa";
        driver.findElement(By.xpath("//textarea[@id='et_pb_contact_message_0']")).sendKeys(Xolisa);
        Thread.sleep(2000);
    }
}



