package Test_Cases;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class Login {
    public static final String excel_location = "C:\\Voss-Assessment\\TestData\\DataSheet.xlsx";
    public FileInputStream fis = new FileInputStream(excel_location);
    public XSSFWorkbook workbook = new XSSFWorkbook(fis);

    public Login() throws IOException {
    }

    @Test
    public void Login_to_page() throws InterruptedException {
        //WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Voss-Assessment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        ChromeDriver driver = new ChromeDriver(op);
        driver.get("https://www.ultimateqa.com/automation/");
        Thread.sleep(5500);
        driver.findElement(new By.ByXPath("//a[contains(text(),'Login automation')]")).click();

        XSSFSheet sheet = workbook.getSheetAt(0);
        String email = sheet.getRow(1).getCell(0).getStringCellValue();
        String password = sheet.getRow(1).getCell(1).getStringCellValue();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"user[email]\"]")).sendKeys(email);
        driver.findElement(By.xpath("//*[@id=\"user[password]\"]")).sendKeys(password);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//body/main[@id='main-content']/div[1]/div[1]/article[1]/form[1]/div[4]/input[1]")).click();
        //Thread.sleep(2000);
        //driver.findElement(By.xpath("/html/body/header/div/div/section[1]/ul/li")).click();
        Thread.sleep(10000);
        List<WebElement> elementName;
        driver.findElement(By.xpath("/html/body/header/div/div/section[1]/ul/li")).click();
        Thread.sleep(10000);
        // Sign out
        driver.findElement(By.xpath("/html/body/header/div/div/section[1]/ul/li/ul/li[4]/a")).click();
        driver.quit();
    }
}
