package Test_Cases;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;

//import static jdk.jfr.internal.handlers.EventHandler.timestamp;

public class Verify_Page_Tittle {
   // public WebDriver driver;
   public ExtentReports reports = new ExtentReports("C:\\Voss-Assessment\\reports\\Assessment-Report.html");
    public ExtentTest test = reports.startTest("verityTitle", "TEST REPORT");
    public Verify_Page_Tittle() throws IOException {

    }

    @Test
    public void verityTitle() throws InterruptedException, IOException {
        // WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Voss-Assessment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        ChromeDriver driver = new ChromeDriver(op);
        driver.get("https://www.ultimateqa.com/automation/");
        Thread.sleep(5500);



        //Actual title
        String my_title = driver.getTitle();
        System.out.println("Title is" + my_title);
        String expected_title = "Automation Practice | Ultimate QA";


        Assert.assertEquals(my_title, expected_title);
        System.out.println("Test complete");

        File scr=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        File dest= new File("C:\\Voss-Assessment\\Screenshot\\Screenshot.png");
        FileUtils.copyFile(scr, dest);


    }




}
