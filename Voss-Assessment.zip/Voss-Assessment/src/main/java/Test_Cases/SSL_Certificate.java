package Test_Cases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


public class SSL_Certificate {

    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Voss-Assessment\\Drivers\\chromedriver.exe");
        //Gloabal profile
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setAcceptInsecureCerts(true);
        ChromeOptions coptions = new ChromeOptions();
        coptions.merge(dc);
        coptions.addArguments("disable-extensions");
        coptions.addArguments("--start-maximized");
        ChromeDriver driver = new ChromeDriver(coptions);
        driver.get("https://www.ultimateqa.com");
        Thread.sleep(5500);
        driver.quit();
    }
    }















