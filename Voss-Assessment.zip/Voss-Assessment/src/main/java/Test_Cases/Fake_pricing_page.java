package Test_Cases;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.FileInputStream;
import java.io.IOException;

public class Fake_pricing_page {


    public static final String excel_location = "C:\\Voss-Assessment\\TestData\\DataSheet.xlsx";
    public FileInputStream fis = new FileInputStream(excel_location);
    public XSSFWorkbook workbook = new XSSFWorkbook(fis);

    public Fake_pricing_page() throws IOException {
    }

    @Test
    public void Fake_pricing_page() throws InterruptedException {
        //WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:\\Voss-Assessment\\Drivers\\chromedriver.exe");
        ChromeOptions op = new ChromeOptions();
        op.addArguments("disable-extensions");
        op.addArguments("--start-maximized");
        ChromeDriver driver = new ChromeDriver(op);
        driver.get("https://www.ultimateqa.com/automation/");
        Thread.sleep(5500);
        driver.findElement(new By.ByXPath("//*[@id=\"post-507\"]/div/div[1]/div/div[2]/div/div[1]/div/div/div/div/ul/li[3]/a")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[@id=\"post-5050\"]/div/div[1]/div/div[1]/div[2]/div[2]/div/div/div/div[4]/a")).click();
        Thread.sleep(1000);
        driver.close();
    }
}